/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minirt.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: candriam <candriam@student.42antananarivo  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/28 09:40:46 by candriam          #+#    #+#             */
/*   Updated: 2024/12/28 12:22:22 by candriam         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINIRT_H
# define MINIRT_H

# define TITLE "miniRT"
# define WIN_WIDTH 1200.0
# define WIN_HEIGHT 720.0

# define ESC 65307
# define CTRL_L 65507
# define CTRL_R 65508
# define SHIFT_L 65505
# define SHIFT_R 65506

# define UP 65362
# define DOWN 65364
# define LEFT 65361
# define RIGHT 65363

# define K_SUM 65451
# define K_MIN 65453

# define K_A 97
# define K_B 98
# define K_C 99
# define K_D 100
# define K_E 101
# define K_F 102
# define K_G 103
# define K_H 104
# define K_I 105
# define K_J 106
# define K_K 107
# define K_L 108
# define K_M 109
# define K_N 110
# define K_O 111
# define K_P 112
# define K_Q 113
# define K_R 114
# define K_S 115
# define K_T 116
# define K_U 117
# define K_V 118
# define K_W 119
# define K_X 120
# define K_Y 121
# define K_Z 122

# define RED 0xFF0000
# define GREEN 0x00FF00
# define BLUE 0x0000FF

# include <unistd.h>
# include <stdlib.h>
# include <stdbool.h>
# include <math.h>
# include <stdio.h>
# include <fcntl.h>
# include "../minilibx-linux/mlx.h"
# include "../includes/libftprintf.h"
# include "../includes/libft.h"

typedef struct s_vector
{
	double	x;
	double	y;
	double	z;
}				t_vector;

typedef struct s_render
{
	void	*image;
}				t_render;

typedef struct s_color
{
	int	red;
	int	green;
	int	blue;
}				t_color;

typedef struct s_camera
{
	double		fov;
	t_vector	position;
	t_vector	orientation;
}				t_camera;

typedef struct s_light
{
	double		intensity;
	t_vector	position;
	t_color		color;
}				t_light;

typedef struct s_sphere
{
	double		radius;
	t_vector	center;
	t_color		color;
}				t_sphere;

typedef struct s_plane
{
	t_vector	position;
	t_vector	normal;
	t_color		color;
}				t_plane;

typedef struct s_cylinder
{
	double		height;
	double		radius;
	t_vector	position;
	t_vector	direction;
	t_color		color;
}				t_cylinder;

typedef struct s_set
{
	void	*mlx;
	void	*win;
}				t_set;

typedef struct s_mouse
{
	int		start_drag[2];
	int		is_leftmouse;
	int		is_rightmouse;
	int		leftmouse;
	int		rightmouse;
}				t_mouse;

typedef struct s_key
{
	int	leftctrl;
	int	rightctrl;
	int	leftshift;
	int	rightshift;
}				t_key;

typedef struct s_minirt
{
	int				nbr_cameras;
	int				nbr_lights;
	int				nbr_spheres;
	int				nbr_planes;
	int				nbr_cylinders;
	t_mouse			mouse;
	t_key			key;
	t_render		*render;
	t_camera		*cameras;
	t_light			*lights;
	t_sphere		*spheres;
	t_plane			*planes;
	t_cylinder		*cylinders;
	t_set			*set;
}				t_minirt;

int		main(int argc, char **argv);
int		close_window(t_minirt *minirt);
void	*safe_malloc(size_t size);

void	free_double_pointer(void **str);
void	free_str_array(char **str);
void	clean_resources(t_minirt *minirt);
void	clean_minirt_struct(t_minirt *minirt);

int		setup_key(int keycode, t_minirt *minirt);
void	handle_tools_one(int keycode, t_minirt *minirt);
int		mouse_release(int mousecode, int x, int y, t_minirt *minirt);
int		key_release(int keycode, t_minirt *minirt);
void	setup_hooks(t_minirt *minirt);

#endif
