# Cahier des Charges du Projet **miniRT**

---

## 1. Objectif
Créer un programme capable de générer des images 2D en utilisant le **lancer de rayons (raytracing)** pour simuler une scène tridimensionnelle avec une caméra et un système d’éclairage.
Les objets géométriques gérés incluront des sphères, des plans, et des cylindres, avec une gestion correcte des intersections, ombres, et effets de lumière.

---

## 2. Fonctionnalités

### Principales
#### **Chargement et Parsing du Fichier de Scène**
- Lire un fichier de description de scène au format `.rt`.
- Valider le format et les données contenues dans le fichier.
- Initialiser les structures de données pour représenter les objets, la caméra, et la lumière.

#### **Génération de l’Image**
- Implémenter un moteur de lancer de rayons pour calculer les couleurs des pixels en fonction des intersections rayons-objets et de l'éclairage.
- Simuler les effets d'éclairage :
  - **Éclairage ambiant** : Intensité lumineuse de base.
  - **Éclairage diffus** : Réflexion diffuse en fonction de la lumière et des normales.
  - **Ombres dures** : Objets bloquant la lumière directe.

#### **Affichage avec la miniLibX**
- Générer une fenêtre avec l’image calculée.
- Permettre une interaction utilisateur fluide (fermeture, etc.).

#### **Interaction Utilisateur**
- **Touches clavier :**
  - `ESC` : Quitter proprement le programme.
- **Souris :**
  - Cliquer sur la croix rouge pour fermer la fenêtre.

---

### Secondaires (Bonus)
- Support de nouveaux objets géométriques (ex. : triangles, cônes).
- Gestion de réflexions ou de transparences.
- Effets avancés (ombrages doux, anti-aliasing, profondeur de champ).
- Transformation dynamique des objets (exemple : rotation ou translation via le clavier).

---

## 3. Contraintes Techniques

### **Entrées et Sorties**
#### **Entrée :**
- Un fichier `.rt` contenant la description de la scène.
- Format libre avec gestion des séparateurs (espaces et sauts de ligne).

#### **Sortie :**
- Une image générée dans une fenêtre.

### **Format de la Scène**
Exemple de fichier `.rt` :
```plaintext
A 0.2 255,255,255       # Éclairage ambiant : intensité et couleur
C -50,0,20 0,0,1 70     # Caméra : position, orientation, champ de vision
L 0,10,20 0.7 255,255,255 # Lumière : position, intensité, couleur
sp 0,0,20 10 255,0,0    # Sphère : centre, rayon, couleur
pl 0,1,0 0,1,0 0,255,0  # Plan : point, normale, couleur
cy 50,0,20 0,1,0 14 50 0,0,255 # Cylindre : position, direction, rayon, hauteur, couleur``````


# Contraintes et Développement pour le Projet miniRT

---

## 1. Contraintes

### **Fichiers à rendre**
- **Code source**
- **Makefile** avec les règles suivantes :
  - `all` : Compile le programme.
  - `clean` : Supprime les fichiers objets.
  - `fclean` : Supprime les fichiers objets et exécutables.
  - `re` : Recompile depuis zéro.

### **Fonctions autorisées**
- **Système** :
  - `open`, `close`, `read`, `write`, `malloc`, `free`, `perror`, `strerror`, `exit`.
- **Mathématiques** : Toutes les fonctions de `math.h`.
- **Affichage** : Toutes les fonctions de la **miniLibX**.

### **Langage et Bibliothèques**
- **libft** : Utilisation autorisée.
- **miniLibX** : Utilisation obligatoire.

---

## 2. Étapes de Développement

### **Étape 1 : Analyse des Besoins**
- Identifier les objets géométriques supportés (sphères, plans, cylindres).
- Comprendre le fonctionnement de la **miniLibX** et tester l’affichage d’une fenêtre simple.
- Étudier les bases du raytracing.

---

### **Étape 2 : Structure du Projet**
1. **Création des fichiers :**
   - **Headers** : `minirt.h`, pour regrouper les structures et prototypes.
   - **Fichiers sources :**
     - `main.c` : Point d’entrée.
     - `parsing.c` : Gestion du fichier `.rt`.
     - `raytracing.c` : Calcul des intersections et gestion des couleurs.
     - `mlx_utils.c` : Utilitaires pour la miniLibX.
   - **Makefile** : Automatisation de la compilation.
2. **Définir les structures** :
   - Vecteurs, couleurs, et lumières.
   - Objets géométriques (sphères, plans, cylindres).
   - Caméra et scène.

---

### **Étape 3 : Parsing du Fichier**
- Lire le fichier `.rt` ligne par ligne.
- Valider les données et créer les objets correspondants.
- Gérer les erreurs de formatage.

---

### **Étape 4 : Implémentation du Raytracing**
1. **Lancer les rayons depuis la caméra :**
   - Calculer la direction de chaque rayon selon le champ de vision (FOV).
2. **Gestion des Intersections :**
   - Calculer les intersections rayon-objet (sphères, plans, cylindres).
   - Identifier l’objet le plus proche.
3. **Calcul des Couleurs :**
   - Appliquer l’éclairage ambiant.
   - Calculer la lumière diffuse en fonction des normales et de la position des lumières.
   - Gérer les ombres dures.

---

### **Étape 5 : Affichage avec la miniLibX**
- Créer une fenêtre et afficher l’image générée.
- Intégrer les interactions clavier et souris :
  - `ESC` : Quitter proprement le programme.
  - Cliquez sur la croix rouge pour fermer la fenêtre.

---

### **Étape 6 : Gestion de la Mémoire**
- Libérer les structures dynamiques allouées.
- Gérer proprement les erreurs (ex. : fichier invalide, allocation impossible).

---

### **Étape 7 : Tests**
1. Créer plusieurs scènes simples (ex. : une sphère, une lumière).
2. Vérifier les résultats visuels pour :
   - Intersections correctes.
   - Ombres et éclairages réalistes.
3. Tester les cas limites :
   - Objets qui se superposent.
   - Scènes vides ou mal formatées.

---

## 3. Livrables
- Fichiers sources.
- Makefile.
- Exemple de fichiers `.rt` (au moins 3 scènes différentes).
- Documentation : Un fichier `README` expliquant le fonctionnement.

---

## 4. Diagramme d'Étapes

### **Chargement de la Scène**
- Lecture du fichier `.rt` → Initialisation des structures internes.

### **Lancer les Rayons**
1. Parcourir chaque pixel de l’image.
2. Calculer les intersections rayons-objets.
3. Appliquer les ombres et éclairages.

### **Afficher l’Image**
- Utiliser la **miniLibX** pour afficher la scène dans une fenêtre.
