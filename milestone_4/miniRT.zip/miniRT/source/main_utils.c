/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_utils.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: candriam <candriam@student.42antananarivo  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/28 09:39:45 by candriam          #+#    #+#             */
/*   Updated: 2024/12/28 16:04:00 by candriam         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minirt.h"

void	setup_hooks(t_minirt *minirt)
{
	mlx_key_hook(minirt->set->win, setup_key, minirt);
	mlx_hook(minirt->set->win, 2, 1L << 0, setup_key, minirt);
	mlx_hook(minirt->set->win, 3, 0, key_release, minirt);
	//mlx_hook(minirt->set->win, 4, 1L << 2, setup_mouse, minirt);
	mlx_hook(minirt->set->win, 5, 1L << 3, mouse_release, minirt);
	mlx_hook(minirt->set->win, 17, 0, close_window, minirt);
}
