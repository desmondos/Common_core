/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: candriam <candriam@student.42antananarivo  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/28 09:39:32 by candriam          #+#    #+#             */
/*   Updated: 2024/12/28 09:58:29 by candriam         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minirt.h"

int	main(int argc, char **argv)
{
	t_minirt	*minirt;

	(void)argc;
	(void)argv;
	minirt = safe_malloc(sizeof(t_minirt));
	minirt->set = malloc(sizeof(t_set));
	if (!minirt->set)
	{
		free(minirt);
		return (1);
	}
	minirt->set->mlx = mlx_init();
	if (!minirt->set->mlx)
	{
		free(minirt->set);
		free(minirt);
		return (1);
	}
	minirt->set->win = mlx_new_window(minirt->set->mlx, WIN_WIDTH, WIN_HEIGHT, TITLE);
	if (!minirt->set->win)
	{
		free(minirt->set->mlx);
		free(minirt->set);
		free(minirt);
		return (1);
	}
	setup_hooks(minirt);
	mlx_loop(minirt->set->mlx);
	clean_resources(minirt);
	clean_minirt_struct(minirt);
	return (0);
}
