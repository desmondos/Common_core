/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cleanup.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: candriam <candriam@student.42antananarivo  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/28 16:01:30 by candriam          #+#    #+#             */
/*   Updated: 2024/12/28 16:02:35 by candriam         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minirt.h"

void	free_double_pointer(void **str)
{
	void	**stash;

	if (str)
	{
		stash = str;
		while (*stash)
		{
			free(*stash);
			*stash = NULL;
			stash++;
		}
		free(str);
	}
}

void	free_str_array(char **str)
{
	int	i;

	i = 0;
	if (str)
	{
		while (str[i])
		{
			free(str[i]);
			i++;
		}
		free(str);
	}
}

void	clean_resources(t_minirt *minirt)
{
	if (minirt->render->image != NULL)
	{
		mlx_destroy_image(minirt->set->mlx, minirt->render->image);
		minirt->render->image = NULL;
	}
	if (minirt->set->win != NULL)
	{
		mlx_destroy_window(minirt->set->mlx, minirt->set->win);
		minirt->set->win = NULL;
	}
	if (minirt->set->mlx != NULL)
	{
		mlx_destroy_display(minirt->set->mlx);
		free(minirt->set->mlx);
		minirt->set->mlx = NULL;
	}
	clean_minirt_struct(minirt);
}

void	clean_minirt_struct(t_minirt *minirt)
{
	if (minirt->render->image)
	{
		mlx_destroy_image(minirt->set->mlx, minirt->render->image);
		minirt->render->image = NULL;
	}
	if (minirt->set->win)
	{
		mlx_destroy_window(minirt->set->mlx, minirt->set->win);
		minirt->set->win = NULL;
	}
	if (minirt->set->mlx)
	{
		mlx_destroy_display(minirt->set->mlx);
		free(minirt->set->mlx);
		minirt->set->mlx = NULL;
	}
}
