/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   win_manager.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: candriam <candriam@student.42antananarivo  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/28 16:03:13 by candriam          #+#    #+#             */
/*   Updated: 2024/12/28 16:03:33 by candriam         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minirt.h"

int	close_window(t_minirt *minirt)
{
	//mlx_destroy_image(minirt->set->mlx, minirt->render->image);
	mlx_destroy_window(minirt->set->mlx, minirt->set->win);
	mlx_destroy_display(minirt->set->mlx);
	free(minirt->set->mlx);
	free(minirt->set);
	free(minirt);
	exit(0);
}
