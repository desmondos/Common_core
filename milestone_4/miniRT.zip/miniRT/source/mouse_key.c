/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mouse_key.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: candriam <candriam@student.42antananarivo  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/28 16:04:41 by candriam          #+#    #+#             */
/*   Updated: 2024/12/28 16:07:34 by candriam         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minirt.h"

int	setup_key(int keycode, t_minirt *minirt)
{
	handle_tools_one(keycode, minirt);
	return (0);
}

void	handle_tools_one(int keycode, t_minirt *minirt)
{
	if (keycode == ESC)
		close_window(minirt);
}

int	mouse_release(int mousecode, int x, int y, t_minirt *minirt)
{
	(void)x;
	(void)y;
	if (mousecode == 1)
		minirt->mouse.is_leftmouse = 0;
	return (0);
}

int	key_release(int keycode, t_minirt *minirt)
{
	if (keycode == CTRL_R || keycode == CTRL_L)
	{
		minirt->key.leftctrl = 0;
		minirt->key.rightctrl = 0;
	}
	return (0);
}
